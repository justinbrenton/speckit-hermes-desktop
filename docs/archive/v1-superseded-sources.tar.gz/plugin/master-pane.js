/**
 * Spec-Kit Hermes v2 - Single master pane with stepper
 * Steps: Spec Builder → Constitution Wizard → Task Board
 */
import { host, PANES_AREA, STATUSBAR_AREAS, Button, Input, Textarea, Badge, ScrollArea, EmptyState, ErrorState, GlyphSpinner, Codicon, icons, Fragment } from '@hermes/plugin-sdk'
import { useState, useEffect } from 'react'
import { jsx, jsxs } from 'react/jsx-runtime'

const ID = 'spec-kit-hermes'

function Stepper({ steps, currentStep, onStepClick, completedSteps }) {
  return jsxs('div', { className: "mb-6", children: [
    jsx('div', { className: "flex items-center", children: steps.map((step, idx) => jsxs(Fragment, { children: [
      jsxs('button', {
        onClick: () => onStepClick(idx),
        disabled: idx > currentStep && !completedSteps.includes(idx),
        className: "flex flex-col items-center relative z-10 " + (
          idx === currentStep ? 'text-(--ui-accent)' :
          completedSteps.includes(idx) ? 'text-(--ui-accent)' :
          'text-(--ui-text-tertiary)'
        ),
        children: [
          jsxs('div', { className: "flex items-center justify-center w-8 h-8 rounded-full border-2 mb-1 " + (
            idx === currentStep ? 'border-(--ui-accent) bg-(--ui-accent)/10' :
            completedSteps.includes(idx) ? 'border-(--ui-accent) bg-(--ui-accent)' :
            'border-(--ui-border) bg-(--ui-bg-tertiary)'
          ), children: [
            completedSteps.includes(idx) && idx !== currentStep ? jsx(Codicon, { icon: icons.check, className: "w-4 h-4" }) : jsx('span', { className: "font-medium", children: idx + 1 })
          ]}),
          jsx('span', { className: "text-xs text-center max-w-24", children: step.title })
        ]
      }),
      idx < steps.length - 1 && jsx('div', { className: "flex-1 h-1 mx-2 " + (
        completedSteps.includes(idx + 1) ? 'bg-(--ui-accent)' : 'bg-(--ui-border)'
      ) })
    ]}, step.id)) })
  ]})
}

function SpecBuilderStep({ specContent, setSpecContent, onNext }) {
  const [isLoading, setIsLoading] = useState(true)
  useEffect(() => {
    setTimeout(() => {
      setSpecContent('# Specification\n\n## Overview\n\n<!-- Edit this specification -->\n\n## Requirements\n\n- [ ] Requirement 1\n- [ ] Requirement 2\n\n## Acceptance Criteria\n\n- [ ] Criteria 1\n- [ ] Criteria 2')
      setIsLoading(false)
    }, 100)
  }, [])
  if (isLoading) {
    return jsxs('div', { className: "flex h-full items-center justify-center", children: [
      jsx(GlyphSpinner, { size: "lg" }),
      jsx('span', { className: "ml-2 text-sm text-(--ui-text-tertiary)", children: "Loading spec..." })
    ]})
  }
  return jsxs('div', { className: "flex h-full flex-col p-4", children: [
    jsx('h3', { className: "font-medium mb-2", children: "Edit Specification" }),
    jsx('p', { className: "text-sm text-(--ui-text-tertiary) mb-4", children: "Write your spec.md content. Requirements with checkboxes will auto-generate tasks in Step 3." }),
    jsx(ScrollArea, { className: "flex-1", children: [
      jsx(Textarea, { value: specContent, onChange: (e) => setSpecContent(e.target.value), className: "w-full h-full font-mono text-sm", placeholder: "No spec.md found..." })
    ]}),
    jsx('div', { className: "flex justify-end mt-4 pt-4 border-t border-(--ui-border)", children: [
      jsx(Button, { variant: "primary", onClick: onNext, children: "Next: Constitution" })
    ]})
  ]})
}

function ConstitutionWizardStep({ answers, setAnswers, onPrev, onNext, onComplete, completedSteps }) {
  const [step, setStep] = useState(0)
  const steps = [
    { id: 'purpose', title: 'Project Purpose', question: 'What is the primary purpose of this project?', options: ['Web Application', 'API Service', 'CLI Tool', 'Library', 'Mobile App', 'Desktop App', 'Data Pipeline', 'ML Model', 'Other'] },
    { id: 'architecture', title: 'Architecture', question: 'What architecture style fits best?', options: ['Monolith', 'Microservices', 'Serverless', 'Modular Monolith', 'Event-Driven', 'Layered', 'Clean Architecture', 'Hexagonal', 'Other'] },
    { id: 'language', title: 'Primary Language', question: 'What is the primary programming language?', options: ['TypeScript', 'Python', 'Go', 'Rust', 'Java', 'C#', 'JavaScript', 'Other'] },
    { id: 'framework', title: 'Framework', question: 'What framework will you use?', options: ['React', 'Next.js', 'FastAPI', 'Express', 'Gin', 'Actix', 'Spring', '.NET', 'None', 'Other'] },
    { id: 'database', title: 'Database', question: 'What database will you use?', options: ['PostgreSQL', 'MySQL', 'SQLite', 'MongoDB', 'Redis', 'DynamoDB', 'None', 'Other'] },
    { id: 'testing', title: 'Testing Strategy', question: 'What testing approach?', options: ['TDD', 'Unit + Integration', 'E2E Focused', 'Property-Based', 'Contract Testing', 'Minimal', 'Other'] },
    { id: 'deployment', title: 'Deployment', question: 'How will you deploy?', options: ['Docker', 'Kubernetes', 'Serverless', 'VM', 'PaaS', 'Static', 'Other'] },
    { id: 'monitoring', title: 'Observability', question: 'What observability stack?', options: ['OpenTelemetry', 'Prometheus/Grafana', 'Datadog', 'Sentry', 'Custom', 'None', 'Other'] },
    { id: 'security', title: 'Security', question: 'What security requirements?', options: ['OAuth2/OIDC', 'API Keys', 'mTLS', 'Zero Trust', 'Compliance (SOC2/HIPAA)', 'Basic Auth', 'None', 'Other'] }
  ]
  const handleNext = () => { if (step < steps.length - 1) setStep(step + 1) }
  const handlePrev = () => { if (step > 0) setStep(step - 1) }
  const currentStep = steps[step]
  const progress = ((step + 1) / steps.length) * 100
  return jsxs('div', { className: "flex h-full flex-col p-4", children: [
    jsxs('div', { className: "mb-4", children: [
      jsxs('div', { className: "flex items-center justify-between text-sm mb-2", children: [
        jsx('span', { children: "Step " + (step + 1) + " of " + steps.length }),
        jsx('span', { className: "text-(--ui-text-tertiary)", children: Math.round(progress) + "%" })
      ]}),
      jsx('div', { className: "h-2 bg-(--ui-bg-tertiary) rounded-full overflow-hidden", children: [
        jsx('div', { className: "h-full bg-(--ui-accent) transition-all duration-300", style: { width: progress + "%" } })
      ]})
    ]}),
    jsxs('div', { className: "flex-1 flex flex-col", children: [
      jsx('h3', { className: "font-medium mb-2", children: currentStep.title }),
      jsx('p', { className: "text-(--ui-text-secondary) mb-6", children: currentStep.question }),
      jsx('div', { className: "flex-1 overflow-y-auto grid grid-cols-2 md:grid-cols-3 gap-3", children: currentStep.options.map(opt => jsxs('button', {
        onClick: () => { setAnswers(prev => ({ ...prev, [currentStep.id]: opt })); handleNext() },
        className: "p-4 rounded-lg border-2 transition-all " + (answers[currentStep.id] === opt ? 'border-(--ui-accent) bg-(--ui-accent)/10' : 'border-(--ui-border) hover:border-(--ui-accent)/50'),
        children: opt
      }, opt)) })
    ]}),
    jsxs('div', { className: "flex justify-between mt-6 pt-4 border-t border-(--ui-border)", children: [
      jsx(Button, { variant: "ghost", onClick: handlePrev, disabled: step === 0, children: "Previous" }),
      jsx(Button, { variant: "primary", onClick: step === steps.length - 1 ? onComplete : handleNext, children: step === steps.length - 1 ? "Save Constitution & Continue" : "Next" })
    ]})
  ]})
}

function TaskBoardStep({ tasks, setTasks, onPrev, specContent }) {
  const [isLoading, setIsLoading] = useState(true)
  useEffect(() => {
    setTimeout(() => {
      const reqMatches = specContent.match(/- \\[ \\] (.+)/g) || []
      const generatedTasks = reqMatches.map((req, i) => ({ id: 'gen-' + i, title: req.replace('- [ ] ', ''), status: 'todo', tags: ['from-spec'] }))
      const defaultTasks = [ { id: '1', title: 'Set up project structure', status: 'done', tags: ['setup'] }, { id: '2', title: 'Implement core features', status: 'todo', tags: ['feature'] } ]
      setTasks([...defaultTasks, ...generatedTasks])
      setIsLoading(false)
    }, 100)
  }, [specContent])
  const columns = [
    { id: 'todo', title: 'To Do', tasks: tasks.filter(t => t.status === 'todo') },
    { id: 'in_progress', title: 'In Progress', tasks: tasks.filter(t => t.status === 'in_progress') },
    { id: 'review', title: 'Review', tasks: tasks.filter(t => t.status === 'review') },
    { id: 'done', title: 'Done', tasks: tasks.filter(t => t.status === 'done') }
  ]
  if (isLoading) {
    return jsxs('div', { className: "flex h-full items-center justify-center", children: [
      jsx(GlyphSpinner, { size: "lg" }),
      jsx('span', { className: "ml-2 text-sm text-(--ui-text-tertiary)", children: "Loading tasks..." })
    ]})
  }
  return jsxs('div', { className: "flex h-full flex-col p-4", children: [
    jsx('h3', { className: "font-medium mb-2", children: "Task Board (Kanban)" }),
    jsx('p', { className: "text-sm text-(--ui-text-tertiary) mb-4", children: "Tasks auto-generated from spec requirements. Drag between columns." }),
    jsx('div', { className: "flex-1 overflow-x-auto", children: [
      jsxs('div', { className: "flex gap-4 h-full min-w-max", children: columns.map(col => jsxs('div', { className: "flex flex-col w-72 bg-(--ui-bg-tertiary) rounded-lg", children: [
        jsxs('div', { className: "px-3 py-2 font-medium border-b border-(--ui-border)", children: [
          col.title,
          jsx(Badge, { variant: "secondary", className: "ml-2", children: col.tasks.length })
        ]}),
        jsx('div', { className: "flex-1 overflow-y-auto p-2 space-y-2", children: col.tasks.map(task => jsxs('div', { className: "p-3 bg-(--ui-bg-secondary) rounded border border-(--ui-border) hover:shadow-md transition-shadow", children: [
          jsx('div', { className: "font-medium text-sm", children: task.title }),
          jsx('div', { className: "flex gap-1 mt-2", children: task.tags.map(tag => jsx(Badge, { key: tag, variant: "outline", className: "text-xs", children: tag })) })
        ]}, task.id)) })
      ]}, col.id)) })
    ]}),
    jsx('div', { className: "flex justify-between mt-4 pt-4 border-t border-(--ui-border)", children: [
      jsx(Button, { variant: "ghost", onClick: onPrev, children: "Previous: Constitution" }),
      jsx(Button, { variant: "primary", onClick: () => { host.notify({ kind: "info", message: "Dispatch to agent/group chat - coming soon" }) }, children: "Dispatch to Agent/Group Chat" })
    ]})
  ]})
}

function SpecKitMasterPane() {
  const [masterStep, setMasterStep] = useState(0)
  const [completedSteps, setCompletedSteps] = useState([])
  const [specContent, setSpecContent] = useState('')
  const [constitutionAnswers, setConstitutionAnswers] = useState({})
  const [tasks, setTasks] = useState([])
  const steps = [ { title: 'Spec', id: 'spec' }, { title: 'Constitution', id: 'constitution' }, { title: 'Tasks', id: 'tasks' } ]
  const handleStepComplete = (nextStep) => { setCompletedSteps(prev => [...new Set([...prev, masterStep])]); setMasterStep(nextStep) }
  const renderStep = () => {
    switch (masterStep) {
      case 0: return jsx(SpecBuilderStep, { specContent, setSpecContent, onNext: () => handleStepComplete(1) })
      case 1: return jsx(ConstitutionWizardStep, { answers: constitutionAnswers, setAnswers: setConstitutionAnswers, onPrev: () => setMasterStep(0), onNext: () => {}, onComplete: () => handleStepComplete(2), completedSteps })
      case 2: return jsx(TaskBoardStep, { tasks, setTasks, onPrev: () => setMasterStep(1), specContent })
      default: return null
    }
  }
  return jsxs('div', { className: "flex h-full flex-col", children: [
    jsxs('div', { className: "p-4 border-b border-(--ui-border)", children: [
      jsxs('div', { className: "flex items-center justify-between mb-4", children: [
        jsx('h2', { className: "font-medium", children: "Spec Kit" }),
        jsx(Button, { variant: "ghost", size: "sm", onClick: () => host.notify({ kind: "info", message: "Sync all with .specify/" }), children: "Sync All" })
      ]}),
      jsx(Stepper, { steps, currentStep: masterStep, completedSteps, onStepClick: (idx) => idx <= masterStep && setMasterStep(idx) })
    ]}),
    jsx('div', { className: "flex-1 overflow-hidden", children: renderStep() })
  ]})
}

function renderMasterPane() { return SpecKitMasterPane() }
function renderStatus() { return jsx(Button, { variant: "ghost", size: "sm", onClick: function() { host.notify({ kind: "info", message: "Spec-Kit Hermes v2.0.0 loaded" }) }, children: jsxs(Fragment, { children: [jsx(Codicon, { icon: icons.book, className: "w-4 h-4 mr-1" }), "Spec-Kit v2"] }) }) }

export default { id: 'spec-kit-hermes', name: 'Spec-Kit Hermes', defaultEnabled: true, register: function(ctx) { ctx.register({ id: 'spec-kit-master', area: PANES_AREA, title: 'Spec Kit', data: { placement: 'right', width: '600px' }, render: renderMasterPane }); ctx.register({ id: 'status', area: STATUSBAR_AREAS.right, order: 100, render: renderStatus }); host.notify({ kind: "info", message: "Spec-Kit Hermes v2 master pane loaded" }) } }